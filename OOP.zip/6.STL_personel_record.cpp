/*-------------<<  Main Function Starts  >>------------*/

#include <algorithm>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

/*-------<<  Declaration of Student Class >>--------*/

class student
{
 public:
                        int rollno;
                        string name;
                        char dob[15];
           
                        bool operator==(const student &student1)
                        {
                           return(rollno==student1.rollno);
                        }
                        bool operator<(const student &student1)
                {
                           return(rollno<student1.rollno);
                        }

                friend ostream& operator << (ostream &out, const student &);

                friend istream& operator >> (istream &in, student &k);
};

ostream & operator << (ostream &out, const student &k)         
            {
                        out<<"\n\t\t"<<k.rollno<<"\t\t"<<k.name<<"\t\t"<<k.dob;
                return out;
            }

istream & operator >> (istream &in , student &k)
            {
                cout<<"\nEnter Roll No : ";
                in>>k.rollno;
                cout<<"\nEnter Name : ";
                in>>k.name;
                cout<<"\nEnter DOB  : ";
                in>>k.dob;
                return in;
            }                     

bool myfunc(const student &k, const student &i2)
            {
                        return(k.rollno<i2.rollno);
            }

/*-------<<  Function Defination For Accept Record >>-------*/

vector<student> read()
            {
                        int n;
                        student k;     
                        vector<student> j;
                        cout<< "\nEnter total no. of students : ";
                        cin>>n;
                        for(int i=0;i<n;i++)
                                    {
                                                cin>>k;
                                                j.push_back(k);
                                    }
                        return j;
            }

void printfunction(const student &k)
            {
                        cout<<k;
            }

/*-------<<  Function Defination For Display Record >>-------*/

void print( const vector<student> &j)
            {
            cout<<"\n\t\tROLL NO\t\tNAME\t\tDATE OF BIRTH";
                        for_each(j.begin(),j.end(),printfunction);

            }

/*-----<<  Function Defination For Inserting New Record >>------*/

void insert(vector<student> &j)
            {
                        student k;
                        cin>>k;
                        j.push_back(k);
            }

/*-------<<  Function Defination For Delete Record >>-------*/

void delet(vector<student>&j)
            {
                        student k;
                        cout<<"\nEnter Student Roll No To Delete : ";
                        cin>>k.rollno;
                        vector<student>::iterator p;
                        p=find(j.begin(),j.end(),k);
                if(p!=j.end())
                                    j.erase(p);
                        else
                                    cout<<"\nNot found ";
            }

/*-------<<  Function Defination For Search Record >>-------*/

void search( vector<student>&j )
            {
                        student k;
                        cout<<"\nEnter Student Roll No To Search  : ";
                        cin>>k.rollno;
                cout<<"\n\n\t\tROLL NO\t\tNAME\t\tDATE OF BIRTH";
                        vector<student>::iterator p;
                        p=find(j.begin(),j.end(),k);
                        if(p!=j.end())
                                    cout<<*p;
                        else
                                    cout<<"\nNot found ";
            }

/*-------<<  Function Defination For Sort Record >>-------*/

void sort( vector<student> &j)
            {
                        sort(j.begin(),j.end(),myfunc);

            }

/*-------------<<  Main Function Starts  >>------------*/

int main()
  {
    vector<student> j;
    int op;
    do
     {
            cout<<"\n\n\t\t-------<< MENU >>---------";
            cout<<"\n\t\t1.Create ";
            cout<<"\n\t\t2.Display ";
            cout<<"\n\t\t3.Insert  ";
            cout<<"\n\t\t4.Delete ";
            cout<<"\n\t\t5.Search ";
            cout<<"\n\t\t6.Sort";
            cout<<"\n\t\t7.Quit";
            cout<<"\n\t\t--------------------------";
            cout<<"\n\t\tEnter your choice : ";
            cin >> op;
            switch(op)
            {
             case 1:
                                     j=read();
                                     break;
             case 2:
                                     print(j);
                                     break;
             case 3:
                                     insert(j);
                                     break;
             case 4:
                                     delet(j);
                                     break;
             case 5:
                                     search(j);
                                     break;
             case 6:
                                     sort(j);
                         print(j);
                                     break;
            }
     }while(op!=7);
 }

/*-------------<<  End Of Main Function  >>---------------*/



